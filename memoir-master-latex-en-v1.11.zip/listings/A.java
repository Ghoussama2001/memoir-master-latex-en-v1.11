public class A { 
	public String a1; 
	package String a2; 
	protected String a3; 
	private String a4; 
	
	public void op1() { ... } 
	public void op2() { ... } 
}
